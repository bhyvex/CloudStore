#include "BaseTask.h"
#include "Error.h"
int BaseTask::recvReq(BaseRequest *req)
{
    return SUCCESSFUL;
}
