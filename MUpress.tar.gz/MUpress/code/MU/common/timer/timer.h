/*
 * @file timer.h
 * @brief  Header file of timer module.
 * 
 * @version 1.0
 * @date Thu Jun 28 11:06:43 2012
 * 
 * @copyright Copyright (C) 2012 UESTC
 * @author lpc<lvpengcheng6300@gmail.com>
 */

#ifndef timer_H_
#define timer_H_

#include "Timer.h"

#endif  // timer_H_

