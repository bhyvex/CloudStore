cp /usr/share/automake*/config.guess .
cp /usr/share/automake*/config.sub .
cp /usr/share/automake*/COPYING .
cp /usr/share/automake*/depcomp .
cp /usr/share/automake*/INSTALL .
cp /usr/share/automake*/install-sh .
cp /usr/share/automake*/missing .
cp /usr/share/libtool/config/ltmain.sh .
