/*
 * @file User.cpp
 * @brief  user infomation
 * 
 * @version 1.0
 * @date Tue Jul 31 14:43:27 2012
 * 
 * @copyright Copyright (C) 2012 UESTC
 * @author lpc<lvpengcheng6300@gmail.com>
 */

#include "User.h"

User::~User()
{

}

User::User()
{
    m_UserId = 0;
    m_TimeOut = 0;
}

