/*
 * @file RuleManager.cpp
 * @brief MU hash rule manager.
 * 
 * @version 1.0
 * @date Wed Jul  4 11:34:46 2012
 * 
 * @copyright Copyright (C) 2012 UESTC
 * @author lpc<lvpengcheng6300@gmail.com>
 */

#include "RuleManager.h"

RuleManager::~RuleManager()
{

}

RuleManager::RuleManager()
{
    m_ModNr = 0;
    m_LastModNr = 0;
}


