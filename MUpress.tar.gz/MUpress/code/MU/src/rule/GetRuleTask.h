/*
 * @file GetRuleTask.h
 * @brief Get whole rules.
 * 
 * @version 1.0
 * @date Thu Jul 19 16:09:00 2012
 * 
 * @copyright Copyright (C) 2012 UESTC
 * @author lpc<lvpengcheng6300@gmail.com>
 */

#ifndef rule_GetRuleTask_H_
#define rule_GetRuleTask_H_



#endif  // rule_GetRuleTask_H_

