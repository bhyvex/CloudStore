/*
 * =====================================================================================
 *
 *       Filename:  protocol.h
 *
 *    Description: 
 *
 *
 *        Version:  1.0
 *        Created:  06/08/12 15:04:21
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Heaven (), zhanwenhan@163.com
 *        Company:  NDSL
 *
 * =====================================================================================
 */
#ifndef _PROTOCOL_H_
#define _PROTOCOL_H_

#include "cstore.protocol.pb.h"
#include "cstore.protocol.h"
#include "MUMacros.h"

#endif // _PROTOCOL_H_
