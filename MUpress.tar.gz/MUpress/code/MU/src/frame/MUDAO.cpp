/*
 * @file MUDAO.cpp
 * @brief Data access object.
 * 
 * @version 1.0
 * @date Mon Jul  2 19:35:05 2012
 * 
 * @copyright Copyright (C) 2012 UESTC
 * @author lpc<lvpengcheng6300@gmail.com>
 */

#include "MUDAO.h"

MUDAO::~MUDAO()
{

}

MUDAO::MUDAO()
{

}

