#ifndef _KEYVALUEPAIR_H_
#define _KEYVALUEPAIR_H_

struct KeyValuePair
{
	string key;
	string value;
};


#endif
