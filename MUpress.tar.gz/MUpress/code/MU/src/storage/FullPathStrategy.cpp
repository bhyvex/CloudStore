#include "FullPathStrategy.h"


FullPathStrategy::FullPathStrategy(string path):
	BuildStrategy(path)
{
}

FullPathStrategy::~FullPathStrategy()
{
}


