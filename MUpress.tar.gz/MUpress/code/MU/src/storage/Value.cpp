#include "Value.h"


string Value::serialize(MUValueInfo *valueinfo)
{
	return ("");
}


MUValueInfo Value::deserialize(string value)
{
	MUValueInfo valueinfo;
	return valueinfo;
}

