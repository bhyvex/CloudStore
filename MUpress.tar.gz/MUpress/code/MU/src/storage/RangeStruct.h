#ifndef _RANGESTRUCT_H_
#define _RANGESTRUCT_H_

//range [start,limit)

struct RangeStruct
{
	std::string start;
	std::string limit;
	void *iterator;
};


#endif
