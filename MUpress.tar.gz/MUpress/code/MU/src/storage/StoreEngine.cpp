#include "StoreEngine.h"


StoreEngine::StoreEngine(string path):
	m_DbPath(path)
{
}

StoreEngine::~StoreEngine()
{
}


