#include "ChannelMappingStrategy.h"


ChannelMappingStrategy::ChannelMappingStrategy()
{
}


ChannelMappingStrategy::~ChannelMappingStrategy()
{
}



